// const links = document.querySelectorAll("nav li");

// burger.addEventListener("click",()=>{
   // nav.classList.toggle("active");
// });

// links.forEach((link)=>{
    // link.addEventListener("click",() => {
        // nav.classList.remove("active");
    // });
// });

// let charger = document.getElementById("charge");
// charger.addEventListener("click",function(){
    // location.reload();
// })


// Sélectionnez l'image et la div par ID
let clic_pt = document.getElementById("pt");
let clic_ang = document.getElementById("ang");
let clic_fr = document.getElementById("fr");

let maDiv = document.getElementById("presentation");

let texteFrancais='Après plusieurs années dans l\'industrie, je décide de faire une reconversion professionelle et de devenir développeur web, \
un domaine qui a toujours été pour moi une passion.<br><br>\
Dans le cadre de ma formation professionnelle Développeur web et web mobile.<br>\
Je recherche un stage en entreprise du 22 janvier 2024 pour une durée de 2 mois.<br><br>\
Ma formation a débuté en juillet 2023, avec de bonnes pratiques sur la création de sites web en Front-end et Back-end.<br><br>\
Nous avons commencé les algorithmes et les sites dynamique avec le JAVASCRIPT.<br><br>\
Nous allons aussi utiliser le langage PHP avec et sans Framework pour effectuer des requêtes SQL sur une base de données MYSQL.';

let textePortugais='Depois de vários anos na indústria, decidi fazer uma mudança de carreira e me tornar um desenvolvedor web, uma área que sempre foi uma paixão para mim, <br><br>\
No âmbito da minha formação profissional em desenvolvimento web e web mobile.<br>\
Estou procurando um estágio em uma empresa a partir de 22 de janeiro de 2024, com duração de 2 meses.<br><br>\
Minha formação começou em julho de 2023, com boas práticas na criação de sites web Front-end e Back-end.<br><br>\
Iniciamos os algoritmos e sites dinâmicos com JavaScript.<br><br>\
Também vamos usar a linguagem PHP com e sem Framework para realizar consultas SQL em um banco de dados MYSQL.';

let texteAnglais='After several years in the industry, I have decided to undergo a career change and become a web developer, a field that has always been a passion for me,<br><br>\
As part of my professional training as a web and mobile web developer.<br>\
I am currently seeking an internship in a company starting on January 22, 2024, for a duration of 2 months.<br><br>\
My training began in July 2023, focusing on best practices for creating Front-end and Back-end websites.<br><br>\
We have also started working on algorithms and dynamic websites using JavaScript.<br><br>\
Additionally, we will be using the PHP language, both with and without frameworks, to perform SQL queries on a MySQL database.'



// Créez une fonction pour changer le texte de la div
function changerTexteFr() {
    maDiv.innerHTML =texteFrancais;
   
}
function changerTextePt() {
    maDiv.innerHTML =textePortugais;
}
function changerTexteAng() {
    maDiv.innerHTML =texteAnglais;
}

 // Ajoutez un gestionnaire d'événements de clic à l'image
 clic_pt.addEventListener("click", changerTextePt);
 clic_ang.addEventListener("click", changerTexteAng);
 clic_fr.addEventListener("click", changerTexteFr);
 
 

