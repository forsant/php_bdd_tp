<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="styleburger2.css">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" href="style.css">
        <title>CV Développeur Web</title>
    </head>
    <body>
        <div id="a4">
            <header>
            <!-- **************************************  Liste   ************************************ -->
            <nav>
                
                <div id="burger"></div>  
                
					<ul>
                        <li><a  href="index.html">ACCUEIL</a></li>
						<li><a href="parcours.html">PARCOURS</a></li>
                        <li><a href="competences.html">COMPÉTENCES</a></li>
						<li><a href="#portfolio">PORTFOLIO</a></li>
					</ul>  
            </nav>
            </header>
                <div class="bandeau-colonne">
                    <div id="presentation" class="presentation"> 

                <form method="post">

                    <label>Nom :</label>
                    <input type="text" name="nom" id="nom" required><br><br>

                    <label>Prénom :</label>
                    <input type="text" name="prenom" id="prenom" required><br><br>

                    <label>Email :</label>
                    <input type="text" name="email" id="email" required><br><br>

                    <label for="message">Message</label>
                    <textarea name="message" id="message" rows="4" cols="50" required></textarea><br><br>
            
                    <input type="submit" value="ENVOYER" class="envoyer">
                </form>
        
                    </div>
                    <div class="msok">
                    </div>
                </div>
                <div class="bandeau-apropo">
				<h3 class="titre">VOTRE MESSAGE</h3></div>
                <div class="petit-rond-fonce"></div>
                <div class="petit-rond-clair"><img src="images/maphoto.png" class="moi"></div>
               

                <div class="bandeau-nom"><img src="images/maphoto.png" class="maphoto">
                    <div class="nom-metier">
                        <h1>DOS SANTOS Helder</h1>
                        <h2>Développeur Web & web mobile</h2>
                    </div></div>
                
                
               
                <div class="contact" >  
                               
                    <p><img src="images/email.png" class="email">hfds45@gmail.com</p>
                    <br /><br />             
                    <p><img src="images/mobile.png" class="mobile">+33 6 51 84 50 66</p>
                    <br /><br />               
                    <p><img src="images/lieu.png" class="lieu">45510 Vienne en Val</p>
					<br />
					<a href="https://linkedin.com/in/helder-dos-santos-46735b200" target="_blank" class="in"><img src="images/in.png"class="in" /></a>  
					<br />
					<p><img src="images/langue.png" class="langue"><img src="images/fr.png" class="fr"><img src="images/pt.png" class="pt"><img src="images/anglais.png" class="ang" ></p>
                    <br />
                    <p><img src="images/systeme.png" class="sys"><img src="images/win.png" class="win"><img src="images/lin.png" class="lin"></p>
                    <br />
                    <p><img src="images/langages.png" class="langages">
                
                </div>
                <ul class="comp">
                    <li class="html">HTML 5</li>
                    <li class="css">CSS 3</li>
                    <li class="js">JAVASCRIPT</li>
                    <li class="php">PHP</li>
                    <li class="sql">SQL</li>
                    <img src="images/outils.png" class="outils">
                    <li class="vs">VS.CODE</li>
                    <li class="np">NOTEPAD++</li>
                    <li class="git">GIT</li>
                    <li class="fp">FREEPLANE</li>
                    <li class="fil">FILEZILLA</li>
                    <li class="pen">PENCIL</li>
                    <li class="figma">FIGMA</li>
                    <li class="wps">WAMPSERVER</li>
                    <li class="xamp">XAMP</li>
                    <li class="mysql">MYSQL_WORKBENCH</li>
                    <li class="loo">LOOPING</li>
                    <li class="psp">PHOTOSHOP</li>
                    <li class="gimp">GIMP</li>
                    <li class="ink">INKSCAPE</li>
                    <li class="xls">EXCEL</li>
                    <li class="ppt">POWERPOINT</li>
                    <li class="doc">WORD</li>
                    <img src="images/course.png" class="course">
                    <img src="images/velo.png" class="velo">
                    <img src="images/moto.png" class="moto">
                    <img src="images/guitare.png" class="guitare">
                </ul>  
                <footer>

                </footer>
            </div>
            <?php
// Connexion à la base de données
$serveur = "sql301.infinityfree.com";
$utilisateur = "if0_35387501";
$motdepasse = "Carvoeiro2395";
$basededonnees = "if0_35387501_mon_formulaire";

$connexion = new mysqli($serveur, $utilisateur, $motdepasse, $basededonnees);

// Vérification de la connexion
if ($connexion->connect_error) {
    die("La connexion à la base de données a échoué : " . $connexion->connect_error);
}

// Vérifie si l'élément avec la clé 'nom' dans le tableau associatif $nom est défini
if (isset ($_POST['nom']))
{
// Récupération des données du formulaire
$nom = $_POST['nom'];
$prenom = $_POST['prenom'];
$email = $_POST['email'];
$message = $_POST['message'];
// Insertion des données dans la base de données
// INSERT INTO contact -> Insert dans la base de donnéés contact
$sql = "INSERT INTO contact (nom, prenom, email, message) VALUES ('$nom', '$prenom', '$email','$message')";

// Execution de la requette sql pour enregistrer les valeures dans la base de données
if ($connexion->query($sql)) {
    echo"<p class='msok'>Message envoyé avec succes</p>";}
    else{
    echo "<p class'msok'>Votre message n'a pas pu être envoyé</p>";
    }
}

// Fermer la connexion à la base de données
$connexion->close();

?>

        <script src="burger.js"></script>
    </body>
</html>